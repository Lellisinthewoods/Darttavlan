﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Darttavlan
{
    class Player
    {
        private string name;
        List<Turns> turns_list;

        public Player(string Name = " ")
        {
            name = Name;
            turns_list = new List<Turns>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Calculatepoints()
        {
            int points = 0;
            foreach (var turn in turns_list)
            {
                points = points+turn.Get_score();
            }
            return points;
        }

        public void Add_turn(int tal1, int tal2, int tal3)
        {
            turns_list.Add(new Turns(tal1, tal2, tal3));
        }

        public void Print_turns()
        {
            Console.WriteLine("Statistik för {0}: ", name);
            foreach (var turn in turns_list)
            {
                Console.WriteLine(turn);
            }
        }

        public override string ToString()
        {
            return string.Format("{0}", name);
        }
    }
}
